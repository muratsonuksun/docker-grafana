import { Emitter } from './utils/emitter';

const appEvents = new Emitter();
export default appEvents;
